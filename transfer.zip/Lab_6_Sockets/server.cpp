#include <iostream>
#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <stdlib.h>

using namespace std;
/* GOALS
	Server communicates with client and sends PID command
	Client returns PID for server and displays message
	Server sends sleep command
	Client sleeps
	Server sends quit command when client sends back "Done" after sleeping

 */

char SOCKPATH[] = "/tmp/lab6";
int main(){
	struct sockaddr_un addr;
	int fd; //our file descriptor for socket
	int cliSock, reSock; //client socket, reading descriptor
	char BUF[100];
	cout << "INITIALIZING" << endl;
	memset(&addr, 0, sizeof(addr)); //zero out our struct
	if ((fd = socket(AF_UNIX, SOCK_STREAM, 0)) < 0){ //Socket creation
		perror("SERVER");
		exit(-1);
	} 

	//Sets socket info and unlinks the file in sockpath in the event it was already being used by a socket
	addr.sun_family = AF_UNIX;
	strncpy(addr.sun_path, SOCKPATH, sizeof(addr.sun_path)-1);
	unlink(SOCKPATH);

	//binding socket to our "address"/path
	if (bind(fd,(struct sockaddr*)&addr, sizeof(addr)) == -1){
		perror("BIND");
		exit(-1);
	}
	
	//set server to listen
	//if there is an error we unlink
	if (listen(fd,5)==-1){
		perror("LISTEN");
		unlink(SOCKPATH);
		close(fd);
		exit(-1);
	}
	//server accepts connections
	if ( (cliSock = accept(fd,NULL,NULL)) == -1){
		perror("ACCEPT");
		unlink(SOCKPATH);
		close(fd);
		exit(-1);
	}
	cout << "CONNECTION ESTABLISHED" <<  endl;
	//begin sending data here
	strncpy(BUF,"Pid",sizeof(BUF)-1);
	write(cliSock, BUF, sizeof(BUF)-1);
	memset(&BUF, 0, sizeof(BUF) - 1);
	//we send a read command for our buffer containing "Pid"
	while((reSock = read(cliSock, BUF, sizeof(BUF)))>0){
		cout << BUF << endl;
		break;
	}
	//we send a command to SLEEP to the client
	memset(&BUF, 0, sizeof(BUF));
	strncpy(BUF,"Sleep", sizeof(BUF)-1);
	write(cliSock, BUF, sizeof(BUF) - 1); 
	memset(&BUF,0,sizeof(BUF));
	cout << "Command \"Sleep\" sent!" << endl;
	reSock = read(cliSock, BUF, sizeof(BUF));
		if(strncmp("Done", BUF, 4) == 0){
			cout << "Client: " << BUF << endl;
			strncpy(BUF,"Quit", sizeof(BUF)-1);
			write(cliSock, BUF, sizeof(BUF)-1);
			memset(&BUF,0,sizeof(BUF));
		}
	cout << "CLIENT CLOSED" << endl;
	cout << "CLEANUP" << endl;
	unlink(SOCKPATH);
	close(cliSock);
	close(fd);
	return 0;
}
