
#include <iostream>
#include <string>
    using namespace std;
    int main()
    {
        cout << "Input data: ";
        string getme;
        string *test;
        int tot;
        cin >> tot;
        cout << "input strings" << endl;
        test = new string[3];
        for (int i = 0; i < tot; i++)
        {
            cin >> getme;
            test[i] = getme;
            cout << test[i] << endl;
        }
        for (int i = 0; i < tot; i++)
        {
            cout << test[i] << endl;
        }

            delete [] test;
       
        
    }