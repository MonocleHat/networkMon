#include <iostream>
#include <string>
#include <sys/socket.h>
#include <sys/un.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
using namespace std;

char SOCKPATH[] = "/tmp/lab6";

int main(){
    struct sockaddr_un addr; //socket struct
    char BUF[100]; //contains responses
    int fd, servCli; //server and file descriptor sockets
    bool running = true;
    //begin
    cout << "CLIENT INIT" << endl;
    memset(&addr, 0, sizeof(addr));
    if((fd = socket(AF_UNIX, SOCK_STREAM, 0)) == -1){ //socket init
        perror("CLIENT SOCK");
        exit(-1);
    }
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, SOCKPATH, sizeof(addr.sun_path)-1);
    
    if (connect(fd, (struct sockaddr*)&addr, sizeof(addr)) < 0){ //connecting to our file path in the tmp dir
        perror("CONNECT");
        close(fd);
        exit(-1);
    }
    cout << "CLIENT CONNECTED" << endl;
    memset(&BUF, 0, sizeof(BUF));
    while( running ){
        servCli = read(fd, BUF, sizeof(BUF)); //read any commands being sent
        if(strncmp("Pid", BUF, 3)==0){ //if the command is Pid execute the below stuff 
            pid_t proc = getpid(); //get process
            char thepid[6];
            sprintf(thepid, "%d", proc); //store process in the pid_t variable
            char full[128] = "This client has PID: ";
            strcat(full,thepid ); //concat strings to form our message
            memset(&BUF, 0, sizeof(BUF));
            strncpy(BUF, full, sizeof(BUF)-1); //pass our message into BUF
            cout << "Sending Process to server" << endl;
            if (write(fd, BUF, servCli) != servCli){ //send BUF to server
                if(servCli>0){
                    perror("write err 1.");
                    close(fd);
                    exit(-1);
                }
            }
        }
        
        if(strncmp("Sleep", BUF, 5)==0){ //if recieve "Sleep"
            cout << "SLEEP RECEIVED" << endl;
            sleep(5); //sleep syscall, pauses process
            memset(&BUF, 0, sizeof(BUF)); //clear buffer
            strncpy(BUF, "Done", sizeof(BUF)-1); //place our message into buffer
            if (write(fd, BUF, servCli) != servCli){ //write to server
                if (servCli>0){
                    perror("write err 2.");
                    close(fd);
                    exit(-1);
                }
            }
        }

        if (strncmp("Quit", BUF, 5) == 0){ //if we receive the Quit request
            cout << "QUIT RECEIVED" << endl;
            running = false;//break the loop
            break;
        }
    }

    cout << "SHUTTING DOWN" << endl;
    close(fd);
    return 0;
}