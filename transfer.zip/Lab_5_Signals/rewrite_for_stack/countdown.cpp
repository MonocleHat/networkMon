#include <fcntl.h>
#include <cstring>
#include <fstream>
#include <iostream>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

using namespace std;
bool sigrecv = false;
static void sig_handler(int);
int main(){
    struct sigaction sigcontrol;
    

    int sig1, sig2, sig3, sig4;
    sigcontrol.sa_handler = sig_handler;
    sigemptyset(&sigcontrol.sa_mask);
    sigcontrol.sa_flags = SA_RESETHAND;
    sig1 = sigaction(SIGUSR1, &sigcontrol, NULL);
	sig2 = sigaction(SIGUSR2, &sigcontrol, NULL);
	sig3 = sigaction(SIGINT, &sigcontrol, NULL);
	sig4 = sigaction(SIGTSTP, &sigcontrol, NULL);
    if(sig1!= 0 || sig2!= 0 || sig3!= 0||sig4!=0){
		cout << "Err at creation" << endl;
		cout << strerror(errno)<<endl;
		return -1;
	} //added after comparison
    cout << "COUNTDOWN ON STANDBY" << endl;
    while(!sigrecv){
        sleep(0.1);
    }
    int counter = 30;
    while(sigrecv){
        cout << "Proc: " << getpid() << " - count: " << counter << endl;
        counter--;
        sleep(1);
    }


}


static void sig_handler(int sig){
	switch(sig){
		case SIGUSR1:
			sigrecv = true;
			cout << "Spinning up" << endl;
			break;
		case SIGINT:
			sigrecv = true;
			cout <<"ctrl-C discarded" << endl;
			break;
		case SIGTSTP:
			sigrecv = true;
			cout << "ctrl-Z discarded" << endl;
			break;
		case SIGUSR2:
			sigrecv = false;
			cout << "shutting down" << endl;
			break;
		default:
			cout << "Undefined Signal" << endl;
	}
	

}