#include <fcntl.h>
#include <fstream>
#include <cstring>
#include <iostream>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
//Program creates 2 processes
//Then those processes call a program "countdown"
//countdown each counts from 10-0, and handles signal interrupts
using namespace std;
int signalThrower();
static void sig_handler(int);
pid_t childProc[3];
bool isParent = true;

int main(){
      struct sigaction sigcontrol;
    sigcontrol.sa_handler = sig_handler;
    sigemptyset(&sigcontrol.sa_mask);
    sigcontrol.sa_flags = SA_RESETHAND;
    sigaction(SIGUSR1, &sigcontrol, NULL);
    cout << "Parent - Start - Process: " << getpid() << endl;

    for (int i = 0; i < 3; i++){
        childProc[i] = fork();
            if (childProc[i] == 0){
                //if proc is zero, then its the child process
                cout << "Child[" << i << "] Process: " << getpid() << endl;
                isParent = false;
                execlp("./countdown", "./countdown", NULL);
                cout << "nothing here" << endl;
            }
    }
    if (isParent){
        sleep(5);
        signalThrower();
    }

    cout << "Parent - End - Reached the end of program" << endl;
    return 0;
}

int signalThrower(){
    int status= -1;
    pid_t proc = 0;
    for (int i = 0; i < 3; i++){
        cout << "Signal thrown to: " << childProc[i] << endl;
        kill(childProc[i], SIGUSR1);
    }

    sleep(5);
    for(int i=0; i<3; i++){
        cout << "Signal thrown to: " << childProc[i] << endl;
        kill(childProc[i], SIGUSR2);
    }
    while(proc>=0){
        proc=wait(&status);
        cout << "Parent - SignalThrower - Status of process: " << status << " - from - " << proc << endl;
    }
    return status;
}
static void sig_handler(int sig){
	switch(sig){
		case SIGUSR1:
			
			cout << " PARENT - Spinning up" << endl;
			break;
		case SIGINT:
			
			cout <<"PARENT - ctrl-C discarded" << endl;
			break;
		case SIGTSTP:
			
			cout << "PARENT - ctrl-Z discarded" << endl;
			break;
		case SIGUSR2:
		
			cout << "PARENT - shutting down" << endl;
			break;
		default:
			cout << "Undefined Signal" << endl;
	}
	

}