#include <iostream>
#include <signal.h>
#include <unistd.h>
using namespace std;
void sig_handler(int sig){
    if (sig == SIGINT){
        cout << "\nSIGINT CAUGHT!" << endl;
        exit(sig);
    }else if (sig == SIGTSTP){
        cout << "\nSIGSTP CAUGHT" << endl;
        //exit(sig);
    }
}

int main(){
    cout << "RUNNING" << endl;
    signal(SIGTSTP,sig_handler); // registers it to handle this
    signal(SIGINT, sig_handler);

    while(1){

    }
    return 0;
}
