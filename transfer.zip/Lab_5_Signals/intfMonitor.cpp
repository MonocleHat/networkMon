#include <fcntl.h>
#include <cstring>
#include <fstream>
#include <iostream>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <signal.h>
using namespace std;

const int MAXBUF=128;
bool isRunning=false;

//TODO: Declare your signal handler function prototype
static void sig_handler(int);

int main(int argc, char *argv[])
{
    //TODO: Declare a variable of type struct sigaction
    //      For sigaction, see http://man7.org/linux/man-pages/man2/sigaction.2.html
	struct sigaction sigcontrol; //sigaction struct which can handle signals and store a pointer to our sighandler function
    char interface[MAXBUF];
    char statPath[MAXBUF];
    const char logfile[]="Network.log";//store network data in Network.log
   int retVal=0;
	int res1, res2, res3, res4;
    //TODO: Register signal handlers for SIGUSR1, SIGUSR2, ctrl-C and ctrl-Z
    //TODO: Ensure there are no errors in registering the handlers
	//initalizing our handlers
	sigcontrol.sa_handler = sig_handler; 
	sigemptyset(&sigcontrol.sa_mask);
	sigcontrol.sa_flags = 0;
	res1 = sigaction(SIGUSR1, &sigcontrol, NULL);
	res2 = sigaction(SIGUSR2, &sigcontrol, NULL);
	res3 = sigaction(SIGINT, &sigcontrol, NULL);
	res4 = sigaction(SIGTSTP, &sigcontrol, NULL);
	if(res1!= 0 || res2!= 0 || res3!= 0||res4!=0){
		cout << "intfMonitor:main: interface:" <<interface<<": Error in signal handler creation" << endl;
		cout << strerror(errno)<<endl;
		return -1;
	} //added after comparison
    strncpy(interface, argv[1], MAXBUF);//The interface has been passed as an argument to intfMonitor
    int fd=open(logfile, O_RDWR | O_CREAT | O_APPEND, S_IRUSR | S_IWUSR);
    cout<<"intfMonitor:main: interface:"<<interface<<":  pid:"<<getpid()<<endl;

    //TODO: Wait for SIGUSR1 - the start signal from the parent
	while(!isRunning){
		sleep(0.1);
	}
    while(isRunning) {
        //gather some stats
        int tx_bytes=0;
        int rx_bytes=0;
        int tx_packets=0;
        int rx_packets=0;
	    
		ifstream infile;
        sprintf(statPath, "/sys/class/net/%s/statistics/tx_bytes", interface);
	    infile.open(statPath);
	    if(infile.is_open()) {
	        infile>>tx_bytes;
	        infile.close();
	    }
        
		sprintf(statPath, "/sys/class/net/%s/statistics/rx_bytes", interface);
	    infile.open(statPath);
	    if(infile.is_open()) {
	        infile>>rx_bytes;
	        infile.close();
	    }
        
		sprintf(statPath, "/sys/class/net/%s/statistics/tx_packets", interface);
	    infile.open(statPath);
	    if(infile.is_open()) {
	        infile>>tx_packets;
	        infile.close();
	    }
        
		sprintf(statPath, "/sys/class/net/%s/statistics/rx_packets", interface);
	    infile.open(statPath);
	    if(infile.is_open()) {
	        infile>>rx_packets;
	        infile.close();
	    }
	    char data[MAXBUF];
	    
		//write the stats into Network.log
	    int len=sprintf(data, "%s: tx_bytes:%d rx_bytes:%d tx_packets:%d rx_packets: %d\n", interface, tx_bytes, rx_bytes, tx_packets, rx_packets);
	    write(fd, data, len);
	    sleep(1);
    }
    close(fd);

    return 0;
}

//TODO: Create a signal handler that starts your program on SIGUSR1 (sets isRunning to true),
//      stops your program on SIGUSR2 (sets isRunning to false),
//      and discards any ctrl-C or ctrl-Z.
//
//      If the signal handler receives a SIGUSR1, the following message should appear on the screen:
//      intfMonitor: starting up
//
//      If the signal handler receives a ctrl-C, the following message should appear on the screen:
//      intfMonitor: ctrl-C discarded
//
//      If the signal handler receives a ctrl-Z, the following message should appear on the screen:
//      intfMonitor: ctrl-Z discarded
//
//      If the signal handler receives a SIGUSR2, the following message should appear on the screen:
//      intfMonitor: shutting down
//
//      If the signal handler receives any other signal, the following message should appear on the screen:
//      intfMonitor: undefined signal

//catches each signal, and performs actions based on which signal is caught.
static void sig_handler(int sig){
	switch(sig){
		case SIGUSR1:
			isRunning = true;
			cout << "intfMonitor: Spinning up" << endl;
			break;
		case SIGINT:
			isRunning = true;
			cout <<"intfMonitor: ctrl-C discarded" << endl;
			break;
		case SIGTSTP:
			isRunning = true;
			cout << "intfMonitor: ctrl-Z discarded" << endl;
			break;
		case SIGUSR2:
			isRunning = false;
			cout << "intfMonitor: shutting down" << endl;
			break;
		default:
			cout << "intfMonitor: Undefined Signal" << endl;
	}
	

}
