//Demonstrating use of IOCTL's
//from advanced programming in linux environment
//this program catches when the window changes and uses an ioctl to detect it
//by matching the current window size in TIOCGWINSZ
//ctrl-c to terminate

#include <sys/termios.h>
#ifndef TIOCGWINSZ
#include <sys/ioctl.h>
#endif
#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <signal.h>
#include <unistd.h>
#include <stddef.h>
using namespace std;


//function here is a static void - returns nothing to the main function
//this function compares the current size of the window and if less than 0
//prints an error message
//otherwise it prints the current window size
static void print_win_size(int fd){
	struct winsize size;
	if (ioctl(fd,TIOCGWINSZ, (char *) &size) < 0){
		perror("TIOCGWINSZ ERR: ");
	}else{
		cout << "Rows: " << size.ws_row << " Cols: " << size.ws_col << endl;
	}
}

static void sig_winch(int signo){
	cout << "SIGWINCH CAUGHT" << endl;
	print_win_size(STDIN_FILENO);
}

int main(void){
	if (isatty(STDIN_FILENO) == 0){
	 	exit(1);
	}
	if (signal(SIGWINCH, sig_winch) == SIG_ERR){
		perror("Sig err");
	}
	print_win_size(STDIN_FILENO);
	for(; ;){
		pause();
	}
}

