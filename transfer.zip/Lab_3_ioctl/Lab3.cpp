//0.1
//Create a menu system to catch our input and call functions to retrieve
//data on different ioctl systems
#include <sys/ioctl.h>
#include <linux/fb.h>
#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
using namespace std;

static void pr_fxd_scr_info(int fd){
    fb_fix_screeninfo fixed;
    
    ioctl(fd,FBIOGET_FSCREENINFO,&fixed);
     cout << "Accel: " << fixed.accel << endl;
     cout << "Visual: " << fixed.visual << endl;
     cout << "Capabilities: " << fixed.capabilities << endl;
     /*
     Accel: 0
     Visual: 2
     Capabilities: 0
     */
    sleep(1);
}

static void pr_var_scr_info(int fd){
    fb_var_screeninfo varinfo;
    ioctl(fd,FBIOGET_VSCREENINFO, &varinfo);
    cout << "xresolution: " << varinfo.xres << endl;
    cout << "yresolution: " << varinfo.yres << endl;
    cout << "bitsperpixel: " << varinfo.bits_per_pixel << endl;
    /*
    xresolution: 800
    yresolution: 600
    bitsperpixel: 32
    */
    
    sleep(1);
}

int main(void){
    int sel = 0;
    int hardware = open("/dev/fb0", O_RDONLY | O_NONBLOCK);
    if(hardware == -1){
        perror("open");
    }
    while(sel != 3){
        
        cout << "------------------" << endl;
        cout << "Select an option" << endl;
        cout << "1. Fixed Screen Info" << endl;
        cout << "2. Variable Screen Info" << endl;
        cout << "3. Exit" << endl;
        cout << "------------------" << endl;
        cin >> sel;
        switch(sel){
            case 1:
            	cout << "------------------" << endl;
	   	cout << "Fixed Screen Info" << endl;
                pr_fxd_scr_info(hardware);
                break;
            case 2:
            	cout << "------------------" << endl;
		cout << "Var Screen Info" << endl;
                pr_var_scr_info(hardware);
                break;
            case 3:
            	cout << "------------------" << endl;
                cout << "exiting" << endl;
                break;
            default:
                cout << "Not a valid option" << endl;
        }
    }
}
