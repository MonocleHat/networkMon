//0.1
//Create a menu system to catch our input and call functions to retrieve
//data on different ioctl systems
#include <sys/ioctl.h>
#include <linux/fb.h>
#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
using namespace std;

static void pr_fxd_scr_info(int fd){
    cout << "PRINT FIXED SCR CALLED" << endl;
    sleep(3);
}

static void pr_var_scr_info(int fd){
    cout << "PRINT VAR SCR CALLED" << endl;
    sleep(3);
}

int main(void){
    int sel = 0;
    int hardware = open("/dev/fb0", O_RDONLY | O_NONBLOCK);
    if(hardware == -1){
        perror("open");
    }
    while(sel != 3){
        
        cout << "------------------" << endl;
        cout << "Select an option" << endl;
        cout << "1. Fixed Screen Info" << endl;
        cout << "2. Variable Screen Info" << endl;
        cout << "3. Exit" << endl;
        cout << "------------------" << endl;
        cin >> sel;
        switch(sel){
            case 1:
                pr_fxd_scr_info(hardware);
                break;
            case 2:
                pr_var_scr_info(hardware);
                break;
            case 3:
                cout << "exiting" << endl;
                sleep(3);
                break;
            default:
                perror("invalid");
        }
    }
}
